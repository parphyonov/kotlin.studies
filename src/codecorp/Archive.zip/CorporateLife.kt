package codecorp

fun main() {
    val jarvis = Accountant(0, "Default Starter Accountant")
    jarvis.work()
}