package codecorp

interface Supplier {
    fun buyThings()
}