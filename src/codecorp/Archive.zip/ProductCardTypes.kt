package codecorp

enum class ProductCardTypes {
    GROCERIES,
    APPLIANCES,
    SHOES
}