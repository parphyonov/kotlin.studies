package codecorp

interface Cleaner {
    fun clean()
}