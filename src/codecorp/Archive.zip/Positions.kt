package codecorp

enum class Positions {
    DIRECTOR,
    ASSISTANT,
    CONSULTANT,
    ACCOUNTANT
}